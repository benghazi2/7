// Technical Analysis Library for Forex/Stock Trading
// Implements multiple indicators for signal generation

export interface Candle {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  timestamp: number;
}

export interface IndicatorResult {
  name: string;
  value: number | string;
  signal: 'BUY' | 'SELL' | 'NEUTRAL';
  strength: number; // 0-100
  description: string;
}

export interface AnalysisResult {
  score: number;
  signal: 'BUY' | 'SELL' | 'NEUTRAL';
  indicators: IndicatorResult[];
  support: number[];
  resistance: number[];
  trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS';
  volatility: 'HIGH' | 'MEDIUM' | 'LOW';
}

// RSI (Relative Strength Index)
function calculateRSI(closes: number[], period: number = 14): { value: number; signal: string; strength: number } {
  if (closes.length < period + 1) {
    return { value: 50, signal: 'NEUTRAL', strength: 0 };
  }

  let gains = 0;
  let losses = 0;

  for (let i = closes.length - period; i < closes.length; i++) {
    const change = closes[i] - closes[i - 1];
    if (change > 0) gains += change;
    else losses -= change;
  }

  const avgGain = gains / period;
  const avgLoss = losses / period;

  if (avgLoss === 0) {
    return { value: 100, signal: 'SELL', strength: 100 };
  }

  const rs = avgGain / avgLoss;
  const rsi = 100 - (100 / (1 + rs));

  let signal: string = 'NEUTRAL';
  let strength: number = 0;

  if (rsi < 30) {
    signal = 'BUY';
    strength = Math.min(100, (30 - rsi) * 3.33);
  } else if (rsi > 70) {
    signal = 'SELL';
    strength = Math.min(100, (rsi - 70) * 3.33);
  } else if (rsi < 40) {
    signal = 'BUY';
    strength = (40 - rsi) * 2;
  } else if (rsi > 60) {
    signal = 'SELL';
    strength = (rsi - 60) * 2;
  }

  return { value: rsi, signal, strength };
}

// MACD (Moving Average Convergence Divergence)
function calculateMACD(closes: number[]): { value: number; signal: string; strength: number; histogram: number } {
  if (closes.length < 26) {
    return { value: 0, signal: 'NEUTRAL', strength: 0, histogram: 0 };
  }

  const ema12 = calculateEMA(closes, 12);
  const ema26 = calculateEMA(closes, 26);
  const macdLine = ema12 - ema26;

  // Calculate signal line (9-period EMA of MACD)
  const macdValues: number[] = [];
  for (let i = 25; i < closes.length; i++) {
    const ema12Val = calculateEMA(closes.slice(0, i + 1), 12);
    const ema26Val = calculateEMA(closes.slice(0, i + 1), 26);
    macdValues.push(ema12Val - ema26Val);
  }

  const signalLine = calculateEMA(macdValues, 9);
  const histogram = macdLine - signalLine;

  let signal: string = 'NEUTRAL';
  let strength: number = 0;

  // Crossover signals
  if (macdLine > signalLine && histogram > 0) {
    signal = 'BUY';
    strength = Math.min(100, Math.abs(histogram) * 100);
  } else if (macdLine < signalLine && histogram < 0) {
    signal = 'SELL';
    strength = Math.min(100, Math.abs(histogram) * 100);
  }

  return { value: macdLine, signal, strength, histogram };
}

// EMA (Exponential Moving Average)
function calculateEMA(data: number[], period: number): number {
  if (data.length < period) return data[data.length - 1] || 0;

  const multiplier = 2 / (period + 1);
  let ema = data.slice(0, period).reduce((a, b) => a + b) / period;

  for (let i = period; i < data.length; i++) {
    ema = (data[i] - ema) * multiplier + ema;
  }

  return ema;
}

// SMA (Simple Moving Average)
function calculateSMA(data: number[], period: number): number {
  if (data.length < period) return data[data.length - 1] || 0;
  return data.slice(-period).reduce((a, b) => a + b) / period;
}

// Bollinger Bands
function calculateBollingerBands(closes: number[], period: number = 20, stdDev: number = 2): {
  upper: number;
  middle: number;
  lower: number;
  signal: string;
  strength: number;
} {
  if (closes.length < period) {
    return { upper: 0, middle: 0, lower: 0, signal: 'NEUTRAL', strength: 0 };
  }

  const middle = calculateSMA(closes, period);
  const slice = closes.slice(-period);
  const variance = slice.reduce((sum, val) => sum + Math.pow(val - middle, 2), 0) / period;
  const std = Math.sqrt(variance);

  const upper = middle + stdDev * std;
  const lower = middle - stdDev * std;
  const currentPrice = closes[closes.length - 1];

  let signal: string = 'NEUTRAL';
  let strength: number = 0;

  const bandwidth = upper - lower;
  const position = (currentPrice - lower) / bandwidth;

  if (currentPrice <= lower) {
    signal = 'BUY';
    strength = 100;
  } else if (currentPrice >= upper) {
    signal = 'SELL';
    strength = 100;
  } else if (position < 0.2) {
    signal = 'BUY';
    strength = (0.2 - position) * 200;
  } else if (position > 0.8) {
    signal = 'SELL';
    strength = (position - 0.8) * 200;
  }

  return { upper, middle, lower, signal, strength };
}

// Stochastic Oscillator
function calculateStochastic(candles: Candle[], period: number = 14): {
  k: number;
  d: number;
  signal: string;
  strength: number;
} {
  if (candles.length < period) {
    return { k: 50, d: 50, signal: 'NEUTRAL', strength: 0 };
  }

  const recentCandles = candles.slice(-period);
  const currentClose = candles[candles.length - 1].close;
  const lowestLow = Math.min(...recentCandles.map(c => c.low));
  const highestHigh = Math.max(...recentCandles.map(c => c.high));

  const k = ((currentClose - lowestLow) / (highestHigh - lowestLow)) * 100;

  // Calculate %D (3-period SMA of %K)
  const kValues: number[] = [];
  for (let i = period - 1; i < candles.length; i++) {
    const slice = candles.slice(i - period + 1, i + 1);
    const close = slice[slice.length - 1].close;
    const low = Math.min(...slice.map(c => c.low));
    const high = Math.max(...slice.map(c => c.high));
    kValues.push(((close - low) / (high - low)) * 100);
  }
  const d = calculateSMA(kValues.slice(-3), 3);

  let signal: string = 'NEUTRAL';
  let strength: number = 0;

  if (k < 20 && d < 20) {
    signal = 'BUY';
    strength = Math.min(100, (20 - k) * 5);
  } else if (k > 80 && d > 80) {
    signal = 'SELL';
    strength = Math.min(100, (k - 80) * 5);
  } else if (k < 30) {
    signal = 'BUY';
    strength = (30 - k) * 2;
  } else if (k > 70) {
    signal = 'SELL';
    strength = (k - 70) * 2;
  }

  return { k, d, signal, strength };
}

// ATR (Average True Range) - Volatility indicator
function calculateATR(candles: Candle[], period: number = 14): number {
  if (candles.length < period + 1) return 0;

  const trueRanges: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const high = candles[i].high;
    const low = candles[i].low;
    const prevClose = candles[i - 1].close;
    const tr = Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose));
    trueRanges.push(tr);
  }

  return calculateSMA(trueRanges.slice(-period), period);
}

// ADX (Average Directional Index) - Trend strength
function calculateADX(candles: Candle[], period: number = 14): { value: number; trend: string; strength: number } {
  if (candles.length < period * 2) {
    return { value: 25, trend: 'NEUTRAL', strength: 0 };
  }

  const plusDM: number[] = [];
  const minusDM: number[] = [];
  const trValues: number[] = [];

  for (let i = 1; i < candles.length; i++) {
    const upMove = candles[i].high - candles[i - 1].high;
    const downMove = candles[i - 1].low - candles[i].low;

    plusDM.push(upMove > downMove && upMove > 0 ? upMove : 0);
    minusDM.push(downMove > upMove && downMove > 0 ? downMove : 0);

    const high = candles[i].high;
    const low = candles[i].low;
    const prevClose = candles[i - 1].close;
    trValues.push(Math.max(high - low, Math.abs(high - prevClose), Math.abs(low - prevClose)));
  }

  const smoothedPlusDM = calculateSMA(plusDM.slice(-period), period);
  const smoothedMinusDM = calculateSMA(minusDM.slice(-period), period);
  const smoothedTR = calculateSMA(trValues.slice(-period), period);

  const plusDI = (smoothedPlusDM / smoothedTR) * 100;
  const minusDI = (smoothedMinusDM / smoothedTR) * 100;

  const dx = Math.abs(plusDI - minusDI) / (plusDI + minusDI) * 100;

  // Simple ADX approximation
  const adxValues: number[] = [];
  for (let i = period; i < plusDM.length; i++) {
    const pDM = calculateSMA(plusDM.slice(i - period + 1, i + 1), period);
    const mDM = calculateSMA(minusDM.slice(i - period + 1, i + 1), period);
    const tr = calculateSMA(trValues.slice(i - period + 1, i + 1), period);
    if (tr > 0) {
      const pDI = (pDM / tr) * 100;
      const mDI = (mDM / tr) * 100;
      adxValues.push(Math.abs(pDI - mDI) / (pDI + mDI) * 100);
    }
  }

  const adx = calculateSMA(adxValues.slice(-period), period);

  let trend: string = 'NEUTRAL';
  let strength: number = Math.min(100, adx);

  if (adx > 25) {
    if (plusDI > minusDI) {
      trend = 'BUY';
    } else {
      trend = 'SELL';
    }
  }

  return { value: adx, trend, strength };
}

// Support and Resistance Levels
function calculateSupportResistance(candles: Candle[]): { support: number[]; resistance: number[] } {
  const support: number[] = [];
  const resistance: number[] = [];

  for (let i = 2; i < candles.length - 2; i++) {
    const current = candles[i];

    // Check for local low (support)
    if (current.low < candles[i - 1].low && current.low < candles[i - 2].low &&
        current.low < candles[i + 1].low && current.low < candles[i + 2].low) {
      support.push(current.low);
    }

    // Check for local high (resistance)
    if (current.high > candles[i - 1].high && current.high > candles[i - 2].high &&
        current.high > candles[i + 1].high && current.high > candles[i + 2].high) {
      resistance.push(current.high);
    }
  }

  // Return only the most recent levels
  return {
    support: support.slice(-3).sort((a, b) => b - a),
    resistance: resistance.slice(-3).sort((a, b) => a - b)
  };
}

// Order Block Detection (SMC concept)
function detectOrderBlocks(candles: Candle[]): { bullish: boolean; bearish: boolean; strength: number } {
  const result = { bullish: false, bearish: false, strength: 0 };

  if (candles.length < 10) return result;

  const recentCandles = candles.slice(-10);
  const avgVolume = recentCandles.reduce((sum, c) => sum + c.volume, 0) / 10;
  const lastCandle = candles[candles.length - 1];

  // Bullish Order Block: Last down candle before a strong up move
  const lastVolume = lastCandle.volume;
  if (lastVolume > avgVolume * 1.5) {
    if (lastCandle.close > lastCandle.open) {
      result.bullish = true;
      result.strength = Math.min(100, (lastVolume / avgVolume) * 30);
    } else {
      result.bearish = true;
      result.strength = Math.min(100, (lastVolume / avgVolume) * 30);
    }
  }

  return result;
}

// Fair Value Gap Detection (SMC concept)
function detectFVG(candles: Candle[]): { bullish: boolean; bearish: boolean; gap: number } {
  const result = { bullish: false, bearish: false, gap: 0 };

  if (candles.length < 3) return result;

  const c1 = candles[candles.length - 3];
  const c2 = candles[candles.length - 2];
  const c3 = candles[candles.length - 1];

  // Bullish FVG: Gap between c1 high and c3 low
  if (c1.high < c3.low) {
    result.bullish = true;
    result.gap = c3.low - c1.high;
  }

  // Bearish FVG: Gap between c1 low and c3 high
  if (c1.low > c3.high) {
    result.bearish = true;
    result.gap = c1.low - c3.high;
  }

  return result;
}

// Main Analysis Function
export function performFullAnalysis(candles: Candle[]): AnalysisResult {
  if (candles.length < 50) {
    return {
      score: 0,
      signal: 'NEUTRAL',
      indicators: [],
      support: [],
      resistance: [],
      trend: 'SIDEWAYS',
      volatility: 'MEDIUM'
    };
  }

  const closes = candles.map(c => c.close);
  const indicators: IndicatorResult[] = [];
  let totalScore = 0;
  let buySignals = 0;
  let sellSignals = 0;

  // RSI Analysis
  const rsi = calculateRSI(closes);
  indicators.push({
    name: 'RSI (14)',
    value: rsi.value.toFixed(2),
    signal: rsi.signal as 'BUY' | 'SELL' | 'NEUTRAL',
    strength: rsi.strength,
    description: rsi.value < 30 ? 'Oversold - Potential Buy' : rsi.value > 70 ? 'Overbought - Potential Sell' : 'Neutral Zone'
  });
  if (rsi.signal === 'BUY') buySignals += rsi.strength;
  else if (rsi.signal === 'SELL') sellSignals += rsi.strength;

  // MACD Analysis
  const macd = calculateMACD(closes);
  indicators.push({
    name: 'MACD',
    value: macd.value.toFixed(4),
    signal: macd.signal as 'BUY' | 'SELL' | 'NEUTRAL',
    strength: macd.strength,
    description: macd.histogram > 0 ? 'Bullish Momentum' : macd.histogram < 0 ? 'Bearish Momentum' : 'Neutral'
  });
  if (macd.signal === 'BUY') buySignals += macd.strength;
  else if (macd.signal === 'SELL') sellSignals += macd.strength;

  // Bollinger Bands
  const bb = calculateBollingerBands(closes);
  indicators.push({
    name: 'Bollinger Bands',
    value: `U: ${bb.upper.toFixed(4)} | M: ${bb.middle.toFixed(4)} | L: ${bb.lower.toFixed(4)}`,
    signal: bb.signal as 'BUY' | 'SELL' | 'NEUTRAL',
    strength: bb.strength,
    description: closes[closes.length - 1] < bb.lower ? 'Below Lower Band - Oversold' : closes[closes.length - 1] > bb.upper ? 'Above Upper Band - Overbought' : 'Within Bands'
  });
  if (bb.signal === 'BUY') buySignals += bb.strength;
  else if (bb.signal === 'SELL') sellSignals += bb.strength;

  // Stochastic
  const stoch = calculateStochastic(candles);
  indicators.push({
    name: 'Stochastic',
    value: `K: ${stoch.k.toFixed(2)} | D: ${stoch.d.toFixed(2)}`,
    signal: stoch.signal as 'BUY' | 'SELL' | 'NEUTRAL',
    strength: stoch.strength,
    description: stoch.k < 20 ? 'Oversold Zone' : stoch.k > 80 ? 'Overbought Zone' : 'Neutral Zone'
  });
  if (stoch.signal === 'BUY') buySignals += stoch.strength;
  else if (stoch.signal === 'SELL') sellSignals += stoch.strength;

  // ADX
  const adx = calculateADX(candles);
  indicators.push({
    name: 'ADX',
    value: adx.value.toFixed(2),
    signal: adx.trend as 'BUY' | 'SELL' | 'NEUTRAL',
    strength: adx.strength,
    description: adx.value > 25 ? 'Strong Trend' : 'Weak/No Trend'
  });
  if (adx.trend === 'BUY') buySignals += adx.strength * 0.5;
  else if (adx.trend === 'SELL') sellSignals += adx.strength * 0.5;

  // EMA Cross (20/50)
  const ema20 = calculateEMA(closes, 20);
  const ema50 = calculateEMA(closes, 50);
  const prevEma20 = calculateEMA(closes.slice(0, -1), 20);
  const prevEma50 = calculateEMA(closes.slice(0, -1), 50);

  let emaSignal: 'BUY' | 'SELL' | 'NEUTRAL' = 'NEUTRAL';
  let emaStrength = 0;

  if (ema20 > ema50 && prevEma20 <= prevEma50) {
    emaSignal = 'BUY';
    emaStrength = 80;
  } else if (ema20 < ema50 && prevEma20 >= prevEma50) {
    emaSignal = 'SELL';
    emaStrength = 80;
  } else if (ema20 > ema50) {
    emaSignal = 'BUY';
    emaStrength = 40;
  } else if (ema20 < ema50) {
    emaSignal = 'SELL';
    emaStrength = 40;
  }

  indicators.push({
    name: 'EMA Cross (20/50)',
    value: `EMA20: ${ema20.toFixed(4)} | EMA50: ${ema50.toFixed(4)}`,
    signal: emaSignal,
    strength: emaStrength,
    description: ema20 > ema50 ? 'Bullish Trend' : ema20 < ema50 ? 'Bearish Trend' : 'Neutral'
  });
  if (emaSignal === 'BUY') buySignals += emaStrength;
  else if (emaSignal === 'SELL') sellSignals += emaStrength;

  // ATR (Volatility)
  const atr = calculateATR(candles);
  const avgPrice = closes.reduce((a, b) => a + b) / closes.length;
  const atrPercent = (atr / avgPrice) * 100;

  let volatility: 'HIGH' | 'MEDIUM' | 'LOW' = 'MEDIUM';
  if (atrPercent > 2) volatility = 'HIGH';
  else if (atrPercent < 0.5) volatility = 'LOW';

  indicators.push({
    name: 'ATR (Volatility)',
    value: `${atr.toFixed(4)} (${atrPercent.toFixed(2)}%)`,
    signal: 'NEUTRAL',
    strength: 0,
    description: volatility === 'HIGH' ? 'High Volatility - Use wider stops' : volatility === 'LOW' ? 'Low Volatility - Range trading' : 'Normal Volatility'
  });

  // Order Blocks (SMC)
  const orderBlocks = detectOrderBlocks(candles);
  indicators.push({
    name: 'Order Block',
    value: orderBlocks.bullish ? 'Bullish OB' : orderBlocks.bearish ? 'Bearish OB' : 'None Detected',
    signal: orderBlocks.bullish ? 'BUY' : orderBlocks.bearish ? 'SELL' : 'NEUTRAL',
    strength: orderBlocks.strength,
    description: 'Institutional activity zone'
  });
  if (orderBlocks.bullish) buySignals += orderBlocks.strength;
  else if (orderBlocks.bearish) sellSignals += orderBlocks.strength;

  // Fair Value Gap (SMC)
  const fvg = detectFVG(candles);
  indicators.push({
    name: 'Fair Value Gap',
    value: fvg.bullish ? `Bullish Gap: ${fvg.gap.toFixed(4)}` : fvg.bearish ? `Bearish Gap: ${fvg.gap.toFixed(4)}` : 'None',
    signal: fvg.bullish ? 'BUY' : fvg.bearish ? 'SELL' : 'NEUTRAL',
    strength: fvg.bullish || fvg.bearish ? 60 : 0,
    description: 'Price imbalance zone - potential retracement target'
  });
  if (fvg.bullish) buySignals += 30;
  else if (fvg.bearish) sellSignals += 30;

  // Support and Resistance
  const { support, resistance } = calculateSupportResistance(candles);

  // Calculate Final Score
  const totalSignals = buySignals + sellSignals;
  if (totalSignals > 0) {
    if (buySignals > sellSignals) {
      totalScore = Math.round((buySignals / (buySignals + sellSignals)) * 100);
    } else {
      totalScore = Math.round((sellSignals / (buySignals + sellSignals)) * 100);
    }
  }

  // Determine overall signal
  let signal: 'BUY' | 'SELL' | 'NEUTRAL' = 'NEUTRAL';
  if (buySignals > sellSignals * 1.5) {
    signal = 'BUY';
  } else if (sellSignals > buySignals * 1.5) {
    signal = 'SELL';
  }

  // Determine trend
  let trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS' = 'SIDEWAYS';
  if (ema20 > ema50 && adx.value > 20) {
    trend = 'BULLISH';
  } else if (ema20 < ema50 && adx.value > 20) {
    trend = 'BEARISH';
  }

  return {
    score: Math.min(100, Math.max(0, totalScore)),
    signal,
    indicators,
    support,
    resistance,
    trend,
    volatility
  };
}
