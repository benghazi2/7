import { NextRequest, NextResponse } from 'next/server';
import { performFullAnalysis, Candle } from '@/lib/technical-analysis';
import { db } from '@/lib/db';

// GET - Get stored analyses
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const symbol = searchParams.get('symbol');

  try {
    if (symbol) {
      const analyses = await db.marketScan.findMany({
        where: { symbol },
        orderBy: { createdAt: 'desc' },
        take: 10
      });
      return NextResponse.json({ analyses });
    }

    const analyses = await db.marketScan.findMany({
      orderBy: { createdAt: 'desc' },
      take: 50
    });
    return NextResponse.json({ analyses });
  } catch (error) {
    console.error('Error fetching analyses:', error);
    return NextResponse.json({ error: 'Failed to fetch analyses' }, { status: 500 });
  }
}

// POST - Perform analysis on market data
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { candles, symbol, timeframe } = body as { candles: Candle[], symbol: string, timeframe: string };

    if (!candles || candles.length < 50) {
      return NextResponse.json({ 
        error: 'Insufficient data for analysis. Need at least 50 candles.' 
      }, { status: 400 });
    }

    // Perform technical analysis
    const analysis = performFullAnalysis(candles);
    const lastCandle = candles[candles.length - 1];
    const prevCandle = candles[candles.length - 2];

    // Save to database
    const savedAnalysis = await db.marketScan.create({
      data: {
        symbol,
        timeframe,
        price: lastCandle.close,
        change: lastCandle.close - prevCandle.close,
        changePercent: ((lastCandle.close - prevCandle.close) / prevCandle.close) * 100,
        volume: lastCandle.volume,
        high24h: Math.max(...candles.slice(-24).map(c => c.high)),
        low24h: Math.min(...candles.slice(-24).map(c => c.low)),
        indicators: JSON.stringify(analysis.indicators),
        signal: analysis.signal,
        score: analysis.score
      }
    });

    return NextResponse.json({
      success: true,
      analysis: {
        ...analysis,
        currentPrice: lastCandle.close,
        symbol,
        timeframe,
        timestamp: Date.now()
      },
      savedId: savedAnalysis.id
    });
  } catch (error) {
    console.error('Analysis error:', error);
    return NextResponse.json({ error: 'Analysis failed' }, { status: 500 });
  }
}
