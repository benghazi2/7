import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { db } from '@/lib/db';
import { performFullAnalysis, Candle } from '@/lib/technical-analysis';

// Initialize ZAI instance
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

// GET - Get all recommendations
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get('status') || 'open';
  const limit = parseInt(searchParams.get('limit') || '20');

  try {
    const recommendations = await db.recommendation.findMany({
      where: { status },
      orderBy: { createdAt: 'desc' },
      take: limit
    });

    return NextResponse.json({ recommendations });
  } catch (error) {
    console.error('Error fetching recommendations:', error);
    return NextResponse.json({ error: 'Failed to fetch recommendations' }, { status: 500 });
  }
}

// POST - Generate new recommendation
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { symbol, candles, timeframe, analysis } = body as { 
      symbol: string; 
      candles: Candle[]; 
      timeframe: string;
      analysis: ReturnType<typeof performFullAnalysis>;
    };

    if (!candles || candles.length < 50) {
      return NextResponse.json({ error: 'Insufficient data' }, { status: 400 });
    }

    const zai = await getZAI();
    const lastCandle = candles[candles.length - 1];
    const price = lastCandle.close;
    const atr = analysis.indicators.find(i => i.name === 'ATR (Volatility)')?.value || 0;

    // Generate AI recommendation
    const prompt = `أنت محلل فني محترف في أسواق المال.

الرمز: ${symbol}
السعر الحالي: ${price}
الإطار الزمني: ${timeframe}

**التحليل الفني:**
- إشارة عامة: ${analysis.signal}
- القوة: ${analysis.score}%
- الاتجاه: ${analysis.trend}
- التقلب: ${analysis.volatility}

**المؤشرات:**
${analysis.indicators.map(i => `- ${i.name}: ${i.value} (${i.signal})`).join('\n')}

**مستويات الدعم:** ${analysis.support.join(', ') || 'غير محدد'}
**مستويات المقاومة:** ${analysis.resistance.join(', ') || 'غير محدد'}

**المطلوب:**
قدم توصية تداول دقيقة بصيغة JSON فقط (بدون أي نص إضافي):
{
  "direction": "BUY أو SELL أو WAIT",
  "entry": "سعر الدخول المقترح",
  "sl": "وقف الخسارة",
  "tp1": "الهدف الأول",
  "tp2": "الهدف الثاني",
  "reason": "سبب التوصية بالعربية",
  "confidence": "نسبة الثقة من 0 إلى 100",
  "riskLevel": "LOW أو MEDIUM أو HIGH"
}`;

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: 'أنت محلل فني محترف. قدم ردودك بصيغة JSON فقط بدون أي نص إضافي.' },
        { role: 'user', content: prompt }
      ],
      thinking: { type: 'disabled' }
    });

    let aiRecommendation;
    try {
      const responseText = completion.choices[0]?.message?.content || '{}';
      // Try to extract JSON from the response
      const jsonMatch = responseText.match(/\{[\s\S]*\}/);
      aiRecommendation = jsonMatch ? JSON.parse(jsonMatch[0]) : {
        direction: analysis.signal,
        entry: price.toString(),
        sl: (price * 0.99).toFixed(5),
        tp1: (price * 1.01).toFixed(5),
        tp2: (price * 1.02).toFixed(5),
        reason: `تحليل فني: ${analysis.signal} بقوة ${analysis.score}%`,
        confidence: analysis.score,
        riskLevel: analysis.volatility === 'HIGH' ? 'HIGH' : 'MEDIUM'
      };
    } catch {
      aiRecommendation = {
        direction: analysis.signal,
        entry: price.toString(),
        sl: (price * 0.99).toFixed(5),
        tp1: (price * 1.01).toFixed(5),
        tp2: (price * 1.02).toFixed(5),
        reason: `تحليل فني: ${analysis.signal} بقوة ${analysis.score}%`,
        confidence: analysis.score,
        riskLevel: analysis.volatility === 'HIGH' ? 'HIGH' : 'MEDIUM'
      };
    }

    // Save recommendation to database
    const savedRecommendation = await db.recommendation.create({
      data: {
        symbol,
        direction: aiRecommendation.direction || analysis.signal,
        entryPrice: parseFloat(aiRecommendation.entry) || price,
        stopLoss: parseFloat(aiRecommendation.sl) || price * 0.99,
        takeProfit1: parseFloat(aiRecommendation.tp1) || price * 1.01,
        takeProfit2: aiRecommendation.tp2 ? parseFloat(aiRecommendation.tp2) : null,
        score: aiRecommendation.confidence || analysis.score,
        reason: aiRecommendation.reason || `تحليل فني: ${analysis.signal}`,
        indicators: JSON.stringify(analysis.indicators),
        timeframe,
        status: 'open'
      }
    });

    return NextResponse.json({
      success: true,
      recommendation: {
        id: savedRecommendation.id,
        symbol,
        direction: aiRecommendation.direction,
        entry: aiRecommendation.entry,
        sl: aiRecommendation.sl,
        tp1: aiRecommendation.tp1,
        tp2: aiRecommendation.tp2,
        reason: aiRecommendation.reason,
        confidence: aiRecommendation.confidence,
        riskLevel: aiRecommendation.riskLevel,
        analysis,
        createdAt: savedRecommendation.createdAt
      }
    });
  } catch (error) {
    console.error('Recommendation error:', error);
    return NextResponse.json({ 
      error: 'Failed to generate recommendation',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

// PUT - Update recommendation status
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, status } = body;

    if (!id || !status) {
      return NextResponse.json({ error: 'ID and status are required' }, { status: 400 });
    }

    const updated = await db.recommendation.update({
      where: { id },
      data: { status }
    });

    return NextResponse.json({ success: true, recommendation: updated });
  } catch (error) {
    console.error('Error updating recommendation:', error);
    return NextResponse.json({ error: 'Failed to update recommendation' }, { status: 500 });
  }
}
