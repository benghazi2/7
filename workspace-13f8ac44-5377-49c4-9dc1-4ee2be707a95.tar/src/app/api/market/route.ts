import { NextRequest, NextResponse } from 'next/server';

// Forex pairs and symbols to track
export const FOREX_PAIRS = [
  { symbol: 'EURUSD=X', name: 'EUR/USD', type: 'forex' },
  { symbol: 'GBPUSD=X', name: 'GBP/USD', type: 'forex' },
  { symbol: 'USDJPY=X', name: 'USD/JPY', type: 'forex' },
  { symbol: 'XAUUSD=X', name: 'Gold/USD', type: 'commodity' },
  { symbol: 'AUDUSD=X', name: 'AUD/USD', type: 'forex' },
  { symbol: 'USDCAD=X', name: 'USD/CAD', type: 'forex' },
  { symbol: 'USDCHF=X', name: 'USD/CHF', type: 'forex' },
  { symbol: 'BTC-USD', name: 'BTC/USD', type: 'crypto' },
  { symbol: 'ETH-USD', name: 'ETH/USD', type: 'crypto' },
  { symbol: 'NZDUSD=X', name: 'NZD/USD', type: 'forex' },
];

interface YahooFinanceCandle {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

async function fetchQuote(symbol: string) {
  try {
    const response = await fetch(
      `https://query1.finance.yahoo.com/v7/finance/quote?symbols=${symbol}`,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        next: { revalidate: 60 } // Cache for 60 seconds
      }
    );

    if (!response.ok) return null;

    const data = await response.json();
    return data.quoteResponse?.result?.[0] || null;
  } catch (error) {
    console.error(`Error fetching quote for ${symbol}:`, error);
    return null;
  }
}

async function fetchHistoricalData(symbol: string, interval: string = '15m'): Promise<YahooFinanceCandle[]> {
  try {
    const rangeMap: Record<string, string> = {
      '1m': '1d',
      '5m': '5d',
      '15m': '1mo',
      '30m': '1mo',
      '1h': '1mo',
      '4h': '3mo',
      '1d': '1y',
    };

    const range = rangeMap[interval] || '1mo';

    const response = await fetch(
      `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=${interval}&range=${range}`,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        next: { revalidate: 60 }
      }
    );

    if (!response.ok) return [];

    const data = await response.json();
    const result = data.chart?.result?.[0];

    if (!result) return [];

    const timestamps = result.timestamp || [];
    const quote = result.indicators?.quote?.[0] || {};

    const candles: YahooFinanceCandle[] = [];

    for (let i = 0; i < timestamps.length; i++) {
      if (quote.open?.[i] !== null && quote.close?.[i] !== null) {
        candles.push({
          timestamp: timestamps[i],
          open: quote.open[i],
          high: quote.high[i],
          low: quote.low[i],
          close: quote.close[i],
          volume: quote.volume?.[i] || 0
        });
      }
    }

    return candles;
  } catch (error) {
    console.error(`Error fetching historical data for ${symbol}:`, error);
    return [];
  }
}

// GET - Fetch market data
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const symbol = searchParams.get('symbol');
  const interval = searchParams.get('interval') || '15m';

  if (symbol) {
    // Fetch data for specific symbol
    const [quote, candles] = await Promise.all([
      fetchQuote(symbol),
      fetchHistoricalData(symbol, interval)
    ]);

    return NextResponse.json({
      symbol,
      quote: quote ? {
        price: quote.regularMarketPrice || candles[candles.length - 1]?.close || 0,
        change: quote.regularMarketChange || 0,
        changePercent: quote.regularMarketChangePercent || 0,
        volume: quote.regularMarketVolume || 0,
        dayHigh: quote.regularMarketDayHigh || 0,
        dayLow: quote.regularMarketDayLow || 0,
        high52w: quote.fiftyTwoWeekHigh || 0,
        low52w: quote.fiftyTwoWeekLow || 0,
      } : null,
      candles,
      interval
    });
  }

  // Fetch all symbols
  const quotesPromises = FOREX_PAIRS.map(async (pair) => {
    const quote = await fetchQuote(pair.symbol);
    return {
      ...pair,
      quote: quote ? {
        price: quote.regularMarketPrice || 0,
        change: quote.regularMarketChange || 0,
        changePercent: quote.regularMarketChangePercent || 0,
        volume: quote.regularMarketVolume || 0,
      } : null
    };
  });

  const results = await Promise.all(quotesPromises);

  return NextResponse.json({
    symbols: results,
    timestamp: Date.now()
  });
}
