import { NextRequest, NextResponse } from 'next/server';
import { performFullAnalysis, Candle } from '@/lib/technical-analysis';
import { db } from '@/lib/db';

// Forex pairs to scan
const FOREX_PAIRS = [
  { symbol: 'EURUSD=X', name: 'EUR/USD', type: 'forex' },
  { symbol: 'GBPUSD=X', name: 'GBP/USD', type: 'forex' },
  { symbol: 'USDJPY=X', name: 'USD/JPY', type: 'forex' },
  { symbol: 'XAUUSD=X', name: 'Gold/USD', type: 'commodity' },
  { symbol: 'AUDUSD=X', name: 'AUD/USD', type: 'forex' },
  { symbol: 'USDCAD=X', name: 'USD/CAD', type: 'forex' },
  { symbol: 'USDCHF=X', name: 'USD/CHF', type: 'forex' },
  { symbol: 'BTC-USD', name: 'BTC/USD', type: 'crypto' },
  { symbol: 'ETH-USD', name: 'ETH/USD', type: 'crypto' },
  { symbol: 'NZDUSD=X', name: 'NZD/USD', type: 'forex' },
];

async function fetchHistoricalData(symbol: string, interval: string = '15m'): Promise<Candle[]> {
  try {
    const rangeMap: Record<string, string> = {
      '1m': '1d',
      '5m': '5d',
      '15m': '1mo',
      '30m': '1mo',
      '1h': '1mo',
      '4h': '3mo',
      '1d': '1y',
    };

    const range = rangeMap[interval] || '1mo';

    const response = await fetch(
      `https://query1.finance.yahoo.com/v8/finance/chart/${symbol}?interval=${interval}&range=${range}`,
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        next: { revalidate: 60 }
      }
    );

    if (!response.ok) return [];

    const data = await response.json();
    const result = data.chart?.result?.[0];

    if (!result) return [];

    const timestamps = result.timestamp || [];
    const quote = result.indicators?.quote?.[0] || {};

    const candles: Candle[] = [];

    for (let i = 0; i < timestamps.length; i++) {
      if (quote.open?.[i] !== null && quote.close?.[i] !== null) {
        candles.push({
          timestamp: timestamps[i],
          open: quote.open[i],
          high: quote.high[i],
          low: quote.low[i],
          close: quote.close[i],
          volume: quote.volume?.[i] || 0
        });
      }
    }

    return candles;
  } catch (error) {
    console.error(`Error fetching data for ${symbol}:`, error);
    return [];
  }
}

// POST - Scan all pairs
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { timeframe = '15m' } = body;

    const results = [];

    for (const pair of FOREX_PAIRS) {
      try {
        // Fetch candles
        const candles = await fetchHistoricalData(pair.symbol, timeframe);

        if (candles.length < 50) {
          results.push({
            ...pair,
            error: 'Insufficient data',
            analysis: null
          });
          continue;
        }

        // Perform analysis
        const analysis = performFullAnalysis(candles);
        const lastCandle = candles[candles.length - 1];
        const prevCandle = candles[candles.length - 2];

        // Save to database
        await db.marketScan.create({
          data: {
            symbol: pair.symbol,
            timeframe,
            price: lastCandle.close,
            change: lastCandle.close - prevCandle.close,
            changePercent: ((lastCandle.close - prevCandle.close) / prevCandle.close) * 100,
            volume: lastCandle.volume,
            high24h: Math.max(...candles.slice(-24).map(c => c.high)),
            low24h: Math.min(...candles.slice(-24).map(c => c.low)),
            indicators: JSON.stringify(analysis.indicators),
            signal: analysis.signal,
            score: analysis.score
          }
        });

        results.push({
          ...pair,
          price: lastCandle.close,
          change: lastCandle.close - prevCandle.close,
          changePercent: ((lastCandle.close - prevCandle.close) / prevCandle.close) * 100,
          analysis,
          error: null
        });
      } catch (error) {
        results.push({
          ...pair,
          error: error instanceof Error ? error.message : 'Unknown error',
          analysis: null
        });
      }
    }

    // Sort by score
    results.sort((a, b) => (b.analysis?.score || 0) - (a.analysis?.score || 0));

    return NextResponse.json({
      success: true,
      timeframe,
      scannedAt: Date.now(),
      results
    });
  } catch (error) {
    console.error('Scan error:', error);
    return NextResponse.json({ 
      error: 'Scan failed',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
