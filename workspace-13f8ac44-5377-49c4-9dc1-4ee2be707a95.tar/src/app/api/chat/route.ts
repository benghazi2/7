import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { db } from '@/lib/db';

// Initialize ZAI instance
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

// GET - Get chat history
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const sessionId = searchParams.get('sessionId');

  if (!sessionId) {
    return NextResponse.json({ messages: [] });
  }

  try {
    const messages = await db.chatMessage.findMany({
      where: { sessionId },
      orderBy: { createdAt: 'asc' }
    });
    return NextResponse.json({ messages });
  } catch (error) {
    console.error('Error fetching chat history:', error);
    return NextResponse.json({ messages: [] });
  }
}

// POST - Send message and get AI response
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { message, sessionId, symbol, enableWebSearch } = body;

    if (!message) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    const zai = await getZAI();

    // Save user message
    await db.chatMessage.create({
      data: {
        sessionId: sessionId || 'default',
        role: 'user',
        content: message
      }
    });

    // Get chat history for context
    const history = await db.chatMessage.findMany({
      where: { sessionId: sessionId || 'default' },
      orderBy: { createdAt: 'asc' },
      take: 20 // Keep last 20 messages for context
    });

    let webSearchContext = '';

    // Perform web search if enabled
    if (enableWebSearch) {
      try {
        const searchQuery = symbol ? `${symbol} ${message} forex trading latest news analysis` : `${message} forex trading latest news`;
        const searchResults = await zai.functions.invoke('web_search', {
          query: searchQuery,
          num: 5
        });

        if (searchResults && searchResults.length > 0) {
          webSearchContext = '\n\n**Latest Market News & Information:**\n' + 
            searchResults.map((r: { name: string; snippet: string; url: string }, i: number) => 
              `${i + 1}. **${r.name}**\n${r.snippet}\nSource: ${r.url}\n`
            ).join('\n');
        }
      } catch (searchError) {
        console.error('Web search error:', searchError);
      }
    }

    // Build system prompt
    const systemPrompt = `أنت مساعد تداول محترف وخبير في أسواق المال (Forex, Crypto, Stocks).
المستخدم يسأل عن: ${symbol || 'السوق العام'}

قدم إجابات دقيقة باللغة العربية تتضمن:
1. تحليل فني مختصر إذا كان السؤال عن زوج معين
2. مستويات الدعم والمقاومة المحتملة
3. المخاطر والفرص
4. نصائح لإدارة المخاطر

كن مختصراً ومباشراً. لا تعطي توصيات مالية قاطعة، بل تحليلات واحتمالات.

${webSearchContext}`;

    // Build messages array
    const messages = [
      { role: 'assistant' as const, content: systemPrompt },
      ...history.slice(-10).map(m => ({
        role: m.role as 'user' | 'assistant',
        content: m.content
      })),
      { role: 'user' as const, content: message }
    ];

    // Get AI response
    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: 'disabled' }
    });

    const aiResponse = completion.choices[0]?.message?.content || 'عذراً، لم أتمكن من معالجة طلبك.';

    // Save AI response
    await db.chatMessage.create({
      data: {
        sessionId: sessionId || 'default',
        role: 'assistant',
        content: aiResponse
      }
    });

    return NextResponse.json({
      success: true,
      response: aiResponse,
      webSearchUsed: enableWebSearch && webSearchContext.length > 0
    });
  } catch (error) {
    console.error('Chat error:', error);
    return NextResponse.json({ 
      error: 'Failed to process message',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

// DELETE - Clear chat history
export async function DELETE(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const sessionId = searchParams.get('sessionId');

  if (!sessionId) {
    return NextResponse.json({ error: 'Session ID is required' }, { status: 400 });
  }

  try {
    await db.chatMessage.deleteMany({
      where: { sessionId }
    });
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error clearing chat history:', error);
    return NextResponse.json({ error: 'Failed to clear history' }, { status: 500 });
  }
}
