'use client';

import { useState, useEffect, useRef } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { 
  TrendingUp, TrendingDown, Minus, RefreshCw, Send, Trash2, 
  Bot, Search, AlertCircle, CheckCircle, Clock, BarChart3,
  Activity, Target, Shield, Zap, MessageSquare
} from 'lucide-react';

// Types
interface Indicator {
  name: string;
  value: string;
  signal: 'BUY' | 'SELL' | 'NEUTRAL';
  strength: number;
  description: string;
}

interface Analysis {
  score: number;
  signal: 'BUY' | 'SELL' | 'NEUTRAL';
  indicators: Indicator[];
  support: number[];
  resistance: number[];
  trend: 'BULLISH' | 'BEARISH' | 'SIDEWAYS';
  volatility: 'HIGH' | 'MEDIUM' | 'LOW';
}

interface ScanResult {
  symbol: string;
  name: string;
  type: string;
  price?: number;
  change?: number;
  changePercent?: number;
  analysis: Analysis | null;
  error: string | null;
}

interface Recommendation {
  id: string;
  symbol: string;
  direction: string;
  entryPrice: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number | null;
  score: number;
  reason: string;
  timeframe: string;
  status: string;
  createdAt: string;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
}

// Forex pairs
const FOREX_PAIRS = [
  { symbol: 'EURUSD=X', name: 'EUR/USD' },
  { symbol: 'GBPUSD=X', name: 'GBP/USD' },
  { symbol: 'USDJPY=X', name: 'USD/JPY' },
  { symbol: 'XAUUSD=X', name: 'Gold/USD' },
  { symbol: 'AUDUSD=X', name: 'AUD/USD' },
  { symbol: 'USDCAD=X', name: 'USD/CAD' },
  { symbol: 'USDCHF=X', name: 'USD/CHF' },
  { symbol: 'BTC-USD', name: 'BTC/USD' },
  { symbol: 'ETH-USD', name: 'ETH/USD' },
  { symbol: 'NZDUSD=X', name: 'NZD/USD' },
];

const TIMEFRAMES = [
  { value: '5m', label: '5 دقائق' },
  { value: '15m', label: '15 دقيقة' },
  { value: '1h', label: 'ساعة' },
  { value: '4h', label: '4 ساعات' },
  { value: '1d', label: 'يومي' },
];

// Signal Badge Component
function SignalBadge({ signal }: { signal: string }) {
  if (signal === 'BUY') {
    return (
      <Badge className="bg-green-500/20 text-green-600 border-green-500/30">
        <TrendingUp className="w-3 h-3 mr-1" /> شراء
      </Badge>
    );
  }
  if (signal === 'SELL') {
    return (
      <Badge className="bg-red-500/20 text-red-600 border-red-500/30">
        <TrendingDown className="w-3 h-3 mr-1" /> بيع
      </Badge>
    );
  }
  return (
    <Badge className="bg-gray-500/20 text-gray-600 border-gray-500/30">
      <Minus className="w-3 h-3 mr-1" /> محايد
    </Badge>
  );
}

// Strength Meter Component
function StrengthMeter({ score, signal }: { score: number; signal: string }) {
  const getColor = () => {
    if (signal === 'BUY') return 'bg-green-500';
    if (signal === 'SELL') return 'bg-red-500';
    return 'bg-gray-500';
  };

  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span>قوة الإشارة</span>
        <span className="font-bold">{score}%</span>
      </div>
      <div className="h-2 bg-muted rounded-full overflow-hidden">
        <div 
          className={`h-full ${getColor()} transition-all duration-500`}
          style={{ width: `${score}%` }}
        />
      </div>
    </div>
  );
}

// Indicator Card Component
function IndicatorCard({ indicator }: { indicator: Indicator }) {
  const getSignalColor = () => {
    if (indicator.signal === 'BUY') return 'text-green-500';
    if (indicator.signal === 'SELL') return 'text-red-500';
    return 'text-gray-500';
  };

  return (
    <div className="p-3 rounded-lg bg-muted/50 border border-border/50">
      <div className="flex justify-between items-start mb-2">
        <span className="text-sm font-medium">{indicator.name}</span>
        <SignalBadge signal={indicator.signal} />
      </div>
      <div className={`text-lg font-bold ${getSignalColor()}`}>
        {indicator.value}
      </div>
      <p className="text-xs text-muted-foreground mt-1">{indicator.description}</p>
      {indicator.strength > 0 && (
        <Progress value={indicator.strength} className="h-1 mt-2" />
      )}
    </div>
  );
}

// Market Scanner Component
function MarketScanner() {
  const [timeframe, setTimeframe] = useState('15m');
  const [scanning, setScanning] = useState(false);
  const [results, setResults] = useState<ScanResult[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleScan = async () => {
    setScanning(true);
    setError(null);
    
    try {
      const response = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ timeframe })
      });

      const data = await response.json();
      
      if (data.success) {
        setResults(data.results);
      } else {
        setError(data.error || 'فشل المسح');
      }
    } catch (err) {
      setError('خطأ في الاتصال');
    } finally {
      setScanning(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Scanner Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5" />
            الماسح الضوئي للسوق
          </CardTitle>
          <CardDescription>
            افحص جميع الأزواج واحصل على تحليل فني شامل
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4 items-end">
            <div className="space-y-2">
              <Label>الإطار الزمني</Label>
              <Select value={timeframe} onValueChange={setTimeframe}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TIMEFRAMES.map(tf => (
                    <SelectItem key={tf.value} value={tf.value}>
                      {tf.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button onClick={handleScan} disabled={scanning} className="gap-2">
              {scanning ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  جاري المسح...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  بدء المسح
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Error Alert */}
      {error && (
        <Card className="border-red-500/50 bg-red-500/10">
          <CardContent className="flex items-center gap-2 p-4">
            <AlertCircle className="w-5 h-5 text-red-500" />
            <span className="text-red-600">{error}</span>
          </CardContent>
        </Card>
      )}

      {/* Results Grid */}
      {results.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {results.map((result, index) => (
            <Card key={index} className={`overflow-hidden ${
              result.analysis?.signal === 'BUY' ? 'border-green-500/30' :
              result.analysis?.signal === 'SELL' ? 'border-red-500/30' : ''
            }`}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg">{result.name}</CardTitle>
                    <CardDescription>{result.symbol}</CardDescription>
                  </div>
                  {result.analysis && (
                    <SignalBadge signal={result.analysis.signal} />
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {result.error ? (
                  <p className="text-red-500 text-sm">{result.error}</p>
                ) : result.analysis ? (
                  <>
                    {/* Price Info */}
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">السعر:</span>
                      <span className="font-mono font-bold">
                        {result.price?.toFixed(5)}
                      </span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted-foreground">التغير:</span>
                      <span className={result.changePercent && result.changePercent > 0 ? 'text-green-500' : 'text-red-500'}>
                        {result.changePercent?.toFixed(2)}%
                      </span>
                    </div>

                    {/* Strength Meter */}
                    <StrengthMeter 
                      score={result.analysis.score} 
                      signal={result.analysis.signal} 
                    />

                    {/* Trend & Volatility */}
                    <div className="flex gap-2 flex-wrap">
                      <Badge variant="outline">
                        {result.analysis.trend === 'BULLISH' ? '📈 صاعد' :
                         result.analysis.trend === 'BEARISH' ? '📉 هابط' : '➡️ عرضي'}
                      </Badge>
                      <Badge variant="outline">
                        {result.analysis.volatility === 'HIGH' ? '🔥 تقلب عالي' :
                         result.analysis.volatility === 'LOW' ? '😴 تقلب منخفض' : '📊 تقلب متوسط'}
                      </Badge>
                    </div>

                    {/* Quick Indicators */}
                    <div className="space-y-2">
                      {result.analysis.indicators.slice(0, 3).map((ind, i) => (
                        <div key={i} className="flex justify-between text-xs">
                          <span className="text-muted-foreground">{ind.name}:</span>
                          <SignalBadge signal={ind.signal} />
                        </div>
                      ))}
                    </div>
                  </>
                ) : null}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Empty State */}
      {results.length === 0 && !scanning && (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <BarChart3 className="w-16 h-16 text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground text-center">
              اضغط على "بدء المسح" لتحليل جميع الأزواج
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Recommendations Component
function Recommendations() {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchRecommendations = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/recommendations?status=open');
      const data = await response.json();
      setRecommendations(data.recommendations || []);
    } catch (error) {
      console.error('Error fetching recommendations:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecommendations();
  }, []);

  const formatDate = (date: string) => {
    return new Date(date).toLocaleString('ar-EG', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                التوصيات الحية
              </CardTitle>
              <CardDescription>
                توصيات التداول المدعومة بالذكاء الاصطناعي
              </CardDescription>
            </div>
            <Button onClick={fetchRecommendations} variant="outline" size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />
              تحديث
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Recommendations List */}
      {loading ? (
        <Card>
          <CardContent className="flex items-center justify-center py-12">
            <RefreshCw className="w-8 h-8 animate-spin text-muted-foreground" />
          </CardContent>
        </Card>
      ) : recommendations.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Activity className="w-16 h-16 text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground text-center">
              لا توجد توصيات حالياً. قم بمسح السوق لإنشاء توصيات جديدة.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {recommendations.map((rec) => (
            <Card key={rec.id} className={`overflow-hidden ${
              rec.direction === 'BUY' ? 'border-l-4 border-l-green-500' :
              rec.direction === 'SELL' ? 'border-l-4 border-l-red-500' :
              'border-l-4 border-l-gray-500'
            }`}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl flex items-center gap-2">
                      {rec.symbol.replace('=X', '').replace('-', '/')}
                      <SignalBadge signal={rec.direction} />
                    </CardTitle>
                    <CardDescription>{rec.timeframe} • {formatDate(rec.createdAt)}</CardDescription>
                  </div>
                  <div className="text-left">
                    <div className="text-2xl font-bold">
                      {rec.score}%
                    </div>
                    <div className="text-xs text-muted-foreground">قوة</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Price Levels */}
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="p-2 rounded-lg bg-muted">
                    <div className="text-xs text-muted-foreground">دخول</div>
                    <div className="font-mono font-bold text-sm">{rec.entryPrice.toFixed(5)}</div>
                  </div>
                  <div className="p-2 rounded-lg bg-red-500/10 border border-red-500/20">
                    <div className="text-xs text-red-500">وقف خسارة</div>
                    <div className="font-mono font-bold text-sm text-red-600">{rec.stopLoss.toFixed(5)}</div>
                  </div>
                  <div className="p-2 rounded-lg bg-green-500/10 border border-green-500/20">
                    <div className="text-xs text-green-500">هدف 1</div>
                    <div className="font-mono font-bold text-sm text-green-600">{rec.takeProfit1.toFixed(5)}</div>
                  </div>
                </div>

                {/* Target 2 if exists */}
                {rec.takeProfit2 && (
                  <div className="p-2 rounded-lg bg-green-500/10 border border-green-500/20 text-center">
                    <div className="text-xs text-green-500">هدف 2</div>
                    <div className="font-mono font-bold text-green-600">{rec.takeProfit2.toFixed(5)}</div>
                  </div>
                )}

                {/* Reason */}
                <div className="p-3 rounded-lg bg-muted/50">
                  <div className="text-xs text-muted-foreground mb-1">التحليل</div>
                  <p className="text-sm">{rec.reason}</p>
                </div>

                {/* Strength Meter */}
                <StrengthMeter score={rec.score} signal={rec.direction} />
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// AI Chat Component
function AIChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedPair, setSelectedPair] = useState('EURUSD=X');
  const [webSearchEnabled, setWebSearchEnabled] = useState(true);
  const [sessionId] = useState(() => `session_${Date.now()}`);
  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;

    const userMessage: ChatMessage = {
      id: `temp_${Date.now()}`,
      role: 'user',
      content: input,
      createdAt: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: input,
          sessionId,
          symbol: selectedPair.replace('=X', '').replace('-', '/'),
          enableWebSearch: webSearchEnabled
        })
      });

      const data = await response.json();

      if (data.success) {
        const assistantMessage: ChatMessage = {
          id: `ai_${Date.now()}`,
          role: 'assistant',
          content: data.response,
          createdAt: new Date().toISOString()
        };
        setMessages(prev => [...prev, assistantMessage]);
      } else {
        const errorMessage: ChatMessage = {
          id: `error_${Date.now()}`,
          role: 'assistant',
          content: 'عذراً، حدث خطأ في معالجة طلبك. يرجى المحاولة مرة أخرى.',
          createdAt: new Date().toISOString()
        };
        setMessages(prev => [...prev, errorMessage]);
      }
    } catch (error) {
      const errorMessage: ChatMessage = {
        id: `error_${Date.now()}`,
        role: 'assistant',
        content: 'خطأ في الاتصال. يرجى التحقق من اتصالك بالإنترنت.',
        createdAt: new Date().toISOString()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const clearChat = async () => {
    try {
      await fetch(`/api/chat?sessionId=${sessionId}`, { method: 'DELETE' });
      setMessages([]);
    } catch (error) {
      setMessages([]);
    }
  };

  return (
    <div className="space-y-4 h-full flex flex-col">
      {/* Chat Header */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4 items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="space-y-1">
                <Label className="text-xs">الزوج</Label>
                <Select value={selectedPair} onValueChange={setSelectedPair}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FOREX_PAIRS.map(pair => (
                      <SelectItem key={pair.symbol} value={pair.symbol}>
                        {pair.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  id="web-search"
                  checked={webSearchEnabled}
                  onCheckedChange={setWebSearchEnabled}
                />
                <Label htmlFor="web-search" className="text-xs">
                  <Search className="w-3 h-3 inline mr-1" />
                  بحث الويب
                </Label>
              </div>
            </div>
            <Button onClick={clearChat} variant="outline" size="sm">
              <Trash2 className="w-4 h-4 mr-2" />
              مسح المحادثة
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Messages Area */}
      <Card className="flex-1 min-h-0">
        <CardContent className="p-0 h-full">
          <ScrollArea className="h-[500px] p-4" ref={scrollRef}>
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center py-12">
                <Bot className="w-16 h-16 text-muted-foreground/50 mb-4" />
                <h3 className="text-lg font-semibold mb-2">المحلل الذكي</h3>
                <p className="text-muted-foreground max-w-md">
                  اسألني عن أي زوج، استراتيجية تداول، أو تحليل السوق. 
                  {webSearchEnabled && ' البحث في الويب مفعل للحصول على أحدث المعلومات.'}
                </p>
                <div className="mt-4 flex flex-wrap gap-2 justify-center">
                  <Button variant="outline" size="sm" onClick={() => setInput('ما هو تحليل EUR/USD اليوم؟')}>
                    تحليل EUR/USD
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setInput('ما هي أفضل استراتيجيات التداول؟')}>
                    استراتيجيات التداول
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => setInput('كيف أدير المخاطر في التداول؟')}>
                    إدارة المخاطر
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
                  >
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted'
                    }`}>
                      {msg.role === 'user' ? '👤' : <Bot className="w-4 h-4" />}
                    </div>
                    <div className={`rounded-lg p-3 max-w-[80%] ${
                      msg.role === 'user' 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-muted'
                    }`}>
                      <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                    </div>
                  </div>
                ))}
                {loading && (
                  <div className="flex gap-3">
                    <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                      <Bot className="w-4 h-4" />
                    </div>
                    <div className="bg-muted rounded-lg p-3">
                      <div className="flex gap-1">
                        <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                        <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                        <span className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Input Area */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-2">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="اكتب سؤالك هنا..."
              className="min-h-[60px] resize-none"
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
            />
            <Button onClick={sendMessage} disabled={loading || !input.trim()} className="h-auto">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Main Page Component
export default function SmartTraderPro() {
  const [activeTab, setActiveTab] = useState('scanner');

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold">AI Smart Trader Pro</h1>
                <p className="text-xs text-muted-foreground">محلل الأسواق المالية الذكي</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="gap-1">
                <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                متصل
              </Badge>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="scanner" className="gap-2">
              <Search className="w-4 h-4" />
              ماسح السوق
            </TabsTrigger>
            <TabsTrigger value="recommendations" className="gap-2">
              <Target className="w-4 h-4" />
              التوصيات
            </TabsTrigger>
            <TabsTrigger value="chat" className="gap-2">
              <MessageSquare className="w-4 h-4" />
              المحلل الذكي
            </TabsTrigger>
          </TabsList>

          <TabsContent value="scanner">
            <MarketScanner />
          </TabsContent>

          <TabsContent value="recommendations">
            <Recommendations />
          </TabsContent>

          <TabsContent value="chat">
            <AIChat />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t bg-card mt-auto">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-wrap justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground">
              © 2024 AI Smart Trader Pro - جميع الحقوق محفوظة
            </p>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Shield className="w-4 h-4" />
                تحليل آمن
              </span>
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                تحديث فوري
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
